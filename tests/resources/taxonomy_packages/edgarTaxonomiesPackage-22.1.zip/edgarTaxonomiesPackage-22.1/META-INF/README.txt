README.txt for edgarTaxonomiesPackage-22.1

This README lives in the META-INF directory of the EDGAR Taxonomies Taxonomy Package.  Taxonomy files are in the parent of this directory.  The metadata files of this directory are the XBRL standard taxonomyPackage.xml file and Oasis standard catalog.xml file.  The taxonomy package file provides the version, entry point for the taxonomy, the versioning report, and in later versions will indicate superseded prior version taxonomy package zip files (that this package zip replaces).

This taxonomy package includes all web-accessible files that might be required to run an SEC filing on EDGAR release 22.1 (also including ifrs/2022 for upcoming release 22.2).

At this time no entry points have been provided as the only purpose is to provide a cache of web-accessible files for operation offline, behind a firewall or just faster operation by loading directly from zip contents instead of expanded disk files.
